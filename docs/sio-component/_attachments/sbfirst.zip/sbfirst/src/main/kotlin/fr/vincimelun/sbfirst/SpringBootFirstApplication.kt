package fr.vincimelun.sbfirst

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class SpringBootFirstApplication

fun main(args: Array<String>) {
	runApplication<SpringBootFirstApplication>(*args)
}
